Owntracks for LoxBerry
======================

A LoxBerry Plugin for Geolocation tracking 
[LoxBerry](http://www.loxwiki.eu/display/LOXBERRY/LoxBerry/).  

Full documentation is available at https://www.loxwiki.eu/display/LOXBERRY/Owntracks  

